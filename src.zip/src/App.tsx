import { BrowserRouter, Routes, Route } from "react-router-dom";
import Register from "./register.tsx";
import Login from "./login.tsx";
import Protected from "./protected.tsx"
import Home from "./home.tsx";
import Todo from "./todo.tsx";

    ;

function App() {
  return (
    <BrowserRouter>
      <Routes>
        
        <Route path="" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/protected" element={<Protected />} />
        <Route path="/home" element={<Home />} />
        <Route path="/todo" element={<Todo/>} /> 
        
      </Routes>
    </BrowserRouter>
  );
}

export default App;