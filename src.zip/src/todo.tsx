
import React, { useEffect, useState } from "react";
import { getTodos, createTodo, deleteTodo, updateTodo } from "./api";

type Todo = {
  id: number;
  text: string;
  completed: boolean;
};

const TodoList: React.FC = () => {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [input, setInput] = useState("");
  const token = localStorage.getItem("token");

  // Fetch todos from backend
  useEffect(() => {
    if (token) {
      getTodos(token)
        .then(res => setTodos(res.data))
        .catch(err => console.error("Error fetching todos:", err));
    }
  }, [token]);

  const addTodo = () => {
    if (input.trim() === "" || !token) return;
    createTodo(token, input)
      .then(res => setTodos([...todos, res.data]))
      .catch(err => console.error("Error adding todo:", err));
    setInput("");
  };

  const toggleComplete = (id: number, current: boolean) => {
    if (!token) return;
    updateTodo(token, id, current ? "undo" : "complete")
      .then(() =>
        setTodos(todos.map(todo =>
          todo.id === id ? { ...todo, completed: !todo.completed } : todo
        ))
      )
      .catch(err => console.error("Error updating todo:", err));
  };

  const removeTodo = (id: number) => {
    if (!token) return;
    deleteTodo(token, id)
      .then(() => setTodos(todos.filter(todo => todo.id !== id)))
      .catch(err => console.error("Error deleting todo:", err));
  };

  return (
    <div className="container">
      <h2 className="heading">📝 My To-Do List</h2>

      <div className="inputContainer">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Add a task..."
          className 
          ="input"
        />
        <button onClick={addTodo} className="addButton">Add</button>
      </div>

      <ul className="list">
        {todos.map(todo => (
          <li key={todo.id} className="listItem">
            <span
              style={{
                textDecoration: todo.completed ? "line-through" : "none",
                flex: 1,
                cursor: "pointer"
              }}
              onClick={() => toggleComplete(todo.id, todo.completed)}
            >
              {todo.text}
            </span>
            <button onClick={() => removeTodo(todo.id)} className="deleteButton">❌</button>
          </li>
        ))}
      </ul>
    </div>
  );
};


export default TodoList;