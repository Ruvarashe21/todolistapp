
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import './Home.css';
const Home: React.FC = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  useEffect(() => {
  const token = localStorage.getItem("token");
  if (!token) {
    navigate("/login");
  }
}, []);

  return (
    <div className="container">
      <h1 className="heading">📝 Welcome to Your To-Do App</h1>
      <p className="subtext">Track your tasks, stay productive, and own your day.</p>

      <button className="button" onClick={() => navigate("/todos")}>
        View My Tasks
      </button>

      <button className="button" style={{ backgroundColor: "#e74c3c" }} onClick={handleLogout}>
        Logout
      </button>
    </div>
  );
};
export default Home;

